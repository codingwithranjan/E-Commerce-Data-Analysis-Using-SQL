
USE EcommerceDB;

INSERT INTO Customers (first_name, last_name, email, registration_date, city, country) VALUES
('John', 'Doe', 'john@example.com', '2023-01-10', 'New York', 'USA'),
('Jane', 'Smith', 'jane@example.com', '2023-03-15', 'Los Angeles', 'USA'),
('Raj', 'Kumar', 'raj@example.com', '2023-05-05', 'Delhi', 'India'),
('Emily', 'Clark', 'emily@example.com', '2023-02-18', 'London', 'UK'),
('Ali', 'Hassan', 'ali@example.com', '2023-04-25', 'Karachi', 'Pakistan');

INSERT INTO Products (product_name, category, price) VALUES
('Laptop', 'Electronics', 70000.00),
('Mouse', 'Electronics', 500.00),
('Keyboard', 'Electronics', 1200.00),
('Chair', 'Furniture', 3500.00),
('Desk', 'Furniture', 8000.00);

INSERT INTO Orders (customer_id, order_date, order_status) VALUES
(1, '2023-06-01', 'Completed'),
(2, '2023-06-03', 'Completed'),
(3, '2023-06-04', 'Pending'),
(4, '2023-06-06', 'Completed'),
(5, '2023-06-07', 'Cancelled'),
(1, '2023-06-08', 'Completed');

INSERT INTO Order_Details (order_id, product_id, quantity, unit_price) VALUES
(1, 1, 1, 70000.00),
(1, 2, 2, 500.00),
(2, 3, 1, 1200.00),
(3, 4, 2, 3500.00),
(4, 5, 1, 8000.00),
(5, 2, 3, 500.00),
(6, 1, 1, 70000.00),
(6, 3, 1, 1200.00);
